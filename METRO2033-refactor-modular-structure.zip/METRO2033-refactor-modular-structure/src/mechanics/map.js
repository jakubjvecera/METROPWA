export function activate() {
  // Zde bude případná logika pro aktivaci mapy
}

export function deactivate() {
  // Zde bude případná logika pro deaktivaci mapy
}