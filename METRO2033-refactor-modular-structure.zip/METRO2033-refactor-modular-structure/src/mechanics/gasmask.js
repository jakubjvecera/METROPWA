export function activate() {
  // Zde bude případná logika pro aktivaci plynové masky
}

export function deactivate() {
  // Zde bude případná logika pro deaktivaci plynové masky
}